import { Component } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms'
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {
  loginForm=new FormGroup({

  id:new FormControl('',Validators.required),
  description:new FormControl('',Validators.required),
  quantity:new FormControl('',Validators.required),
  unitPrice:new FormControl('',Validators.required)
})

LoginForm()
{
  console.warn(this.loginForm.value)
}
get id()
{
  return this.loginForm.get('id')
}
get description()
{
  return this.loginForm.get('description')
}
get quantity()
{
  return this.loginForm.get('quantity')
}
get unitPrice()
{
  return this.loginForm.get('unitPrice')
}

}
